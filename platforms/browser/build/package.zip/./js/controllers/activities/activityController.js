var ActivityController=function ($scope, $http, $filter,myService) {

var options = salesNavigator.getCurrentPage().options;
$scope.customer=options.activity.cardName;

ons.createPopover('views/activities/activityOptions.html').then(function(popover) {
      $scope.popover = popover;
       myService.setPopover($scope.popover);
    });

$scope.newOrder=function(){


var options = salesNavigator.getCurrentPage().options;
order=new Order();
order.cardName=options.activity.cardName;
order.cardCode=options.activity.cardCode;
order.docDate=new Date();
order.taxDate=new Date();
order.objType="17";

//alert(order.lines.length);
salesNavigator.pushPage('views/orders/newOrder.html', {order : order,form:'activity'});

};

$scope.newPayment=function(){


var options = salesNavigator.getCurrentPage().options;
payment=new Payment();
payment.cardName=options.activity.cardName;
payment.cardCode=options.activity.cardCode;
payment.docDate=new Date();
payment.taxDate=new Date();
payment.objType="24";
payment.payNoDoc='N'
//alert(order.lines.length);
salesNavigator.pushPage('views/payments/newPayment.html', {payment : payment,form:'activity'});

//alert(order.lines.length);


};


$scope.showBP=function(){


var options = salesNavigator.getCurrentPage().options;

 salesNavigator.pushPage('views/bp/customerDetail.html', {businessPartner : options.activity.businessPartner});
//alert(order.lines.length);


};

 




}

ActivityController.$inject = ["$scope", "$http", "$filter","myService"];

oneApp.controller('ActivityController', ActivityController);


var ActController=function ($scope, $http, $filter,myService) {


$scope.startActivity =function(){

$scope.popover = myService.getPopover();    
    
    $scope.popover.hide();
 

var onSuccess = function(position) {
    alert('Latitude: '          + position.coords.latitude          + '\n' +
          'Longitude: '         + position.coords.longitude         + '\n' +
          'Altitude: '          + position.coords.altitude          + '\n' +
          'Accuracy: '          + position.coords.accuracy          + '\n' +
          'Altitude Accuracy: ' + position.coords.altitudeAccuracy  + '\n' +
          'Heading: '           + position.coords.heading           + '\n' +
          'Speed: '             + position.coords.speed             + '\n' +
          'Timestamp: '         + position.timestamp                + '\n');
};

// onError Callback receives a PositionError object
//
function onError(error) {
    alert('code: '    + error.code    + '\n' +
          'message: ' + error.message + '\n');
}

navigator.geolocation.getCurrentPosition(onSuccess, onError);
      

  }


  $scope.closeActivity =function(){

$scope.popover = myService.getPopover();    
    
    $scope.popover.hide();
      

  }

}

ActController.$inject = ["$scope", "$http", "$filter","myService"];

oneApp.controller('ActController', ActController);



oneApp.service("myService", function(){
  var sharedPopover

  var setPopover = function(pop){
    sharedPopover = pop;
  };

  var getPopover = function(){
    return sharedPopover;
  };

  return {
    setPopover: setPopover,
    getPopover: getPopover,
  };
  });