var BusinessPartnerController=function ($scope, $http, $filter) {

     $scope.showDetail = function(index) {
     var selectedItem = $scope.businessPartners[index];
      //$data.selectedItem = selectedItem;

     // alert('prueba');
      //alert(selectedItem.itemCode);
      salesNavigator.pushPage('views/bp/customerDetail.html', {businessPartner : selectedItem});
    };


$scope.selectBP = function(index) {
     var selectedItem = $scope.businessPartners[index];
      //$data.selectedItem = selectedItem;

     // alert('prueba');
    //  alert(selectedItem.cardCode);
      salesNavigator.pushPage('views/orders/newOrder.html', {businessPartner : selectedItem});
    };

var businessPartners=new Array();

dataBase.transaction(selectRecords, errorInQuery, successResults);

function selectRecords(tx)
{
    tx.executeSql('SELECT * FROM OCRD T0, OCTG T1, OCPR T2 WHERE T0.paymentGroupNum=T1.PaymentGroupNum AND T0.contactCode=T2.contactCode', [], successResults,errorInQuery);
}
 
function successResults(tx,results)
{
    
   var nLength = results.rows.length;
       
        //alert(nLength);
       for(var c=0;c<nLength;c++){
        
		    // alert(results.rows.item(c).itemCode);
		     var businessPartner = new BusinessPartner
		    (results.rows.item(c).cardCode,
		    results.rows.item(c).cardName,
		    results.rows.item(c).licTradNum,
		    results.rows.item(c).email,
		    results.rows.item(c).phone1,
        results.rows.item(c).phone2,
        results.rows.item(c).balance,
        results.rows.item(c).contactCode,
        results.rows.item(c).contactName,
        results.rows.item(c).paymentGroupNum,
        results.rows.item(c).pymntGroup,
        results.rows.item(c).slpCode,
        results.rows.item(c).address,
        results.rows.item(c).mailAddress);
		     // alert(item.itemCode+ ' ' + item.itemName +'stock '+results.rows.item(c).stock);
			  businessPartners.push(businessPartner);
	
        }
        
    $scope.businessPartners=businessPartners;
    $scope.$apply();
    
}

function errorInQuery(tx,error)
{
    
    alert(error.message); 
//alert(JSON.stringify(results));
      
} 




}

BusinessPartnerController.$inject = ["$scope", "$http", "$filter"];

oneApp.controller('BusinessPartnerController', BusinessPartnerController
  );
