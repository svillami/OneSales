var  PaymentsController=function ($scope, $http, $filter) {

var payment;
$scope.newPayment = function() { 

payment=new Payment();
payment.cardName="";
payment.docDate=new Date('yyyy-MM-dd');
payment.taxDate=new Date('yyyy-MM-dd');
payment.objType="24";
payment.payNoDoc='N'
//alert(order.lines.length);
salesNavigator.pushPage('views/payments/newPayment.html', {payment : payment});
};

$scope.getParams = function() { 
    

    var options = salesNavigator.getCurrentPage().options;

//alert(options.item.itemCode);
    return options.payment ;
  };

$scope.activarPagoCuenta = function() { 

 var options = salesNavigator.getCurrentPage().options; 
$scope.pagoCuenta= $scope.check;  
if ($scope.check)
{
options.payment.payNoDoc='Y';
}
else
{
options.payment.payNoDoc='N';
}

  };

$scope.goToSelectBP = function() { 
    

    var options = salesNavigator.getCurrentPage().options;
 if (options.form!="activity"){
    salesNavigator.pushPage('views/payments/selectClientPayments.html', {payment : options.payment});
  }
  };


$scope.addPayNoDocSum = function() { 
    

    var options = salesNavigator.getCurrentPage().options;

    options.payment.payNoDocSum=$scope.payNoDocSum;
  };

  
$scope.goToPendingDocs = function() { 
    

    var options = salesNavigator.getCurrentPage().options;
  

  if (options.payment.payNoDoc=='N'){
        if (options.payment.cardCode!=null && options.payment.cardCode!="")
        {
        
        if (options.payment.invoices.length==0){
          
          salesNavigator.pushPage('views/payments/pendingDocs.html', {payment : options.payment});
          
          }
         else{
        
          salesNavigator.pushPage('views/payments/addPaidToDatePayment.html', {payment : options.payment});

         }

        

        }else{
            ons.notification.alert({
             message: 'Debe seleccionar un socio de negocio',title: 'Error'
            });   
     }
   }
   else{
ons.notification.alert({
             message: 'Con pago a cuenta no puede seleccionar documento',title: 'Error'
            });   

   }

};
$scope.goToPaymentMeans = function() { 
    

    var options = salesNavigator.getCurrentPage().options;


   
  
if (options.payment.cardCode!=null && options.payment.cardCode!="")
{
       // options.order.docDate=$scope.DocDate;
       // options.order.taxDate=$scope.DocDueDate;
       // options.order.comments=$scope.Comments;
       
      //  alert( options.order.lines.length);

if (options.payment.invoices.length>0 || options.payment.payNoDocSum>0){
 
 salesNavigator.pushPage('views/payments/meansOfPayment.html', {payment : options.payment});

}else{

  ons.notification.alert({
             message: 'Debe seleccionar un pago a cuenta o al menos un documento a pagar',title: 'Error'
        }); 
}
       
          
  }      
else{
       ons.notification.alert({
             message: 'Debe seleccionar un socio de negocio',title: 'Error'
        });   
     }



  };



}

PaymentsController.$inject = ["$scope", "$http", "$filter"];

oneApp.controller('PaymentsController', PaymentsController);


var SelectBPController=function ($scope, $http, $filter) {

$scope.selectBP = function(index) {
    
     var options = salesNavigator.getCurrentPage().options;
     var selectedItem = $scope.businessPartners[index];

  	 options.payment.cardCode=selectedItem.cardCode;
  	 options.payment.cardName=selectedItem.cardName;
     // options.order.cardName=selectedItem.cardName;
     // options.order.cardCode=selectedItem.cardCode;
     
      salesNavigator.popPage('views/payment/newPayment.html');
    };

var businessPartners=new Array();

dataBase.transaction(selectRecords, errorInQuery, successResults);

function selectRecords(tx)
{
    tx.executeSql('SELECT * FROM OCRD T0, OCTG T1, OCPR T2 WHERE T0.paymentGroupNum=T1.PaymentGroupNum AND T0.contactCode=T2.contactCode', [], successResults,errorInQuery);
}
 
function successResults(tx,results)
{
    
   var nLength = results.rows.length;
       
        //alert(nLength);
       for(var c=0;c<nLength;c++){
        
		    // alert(results.rows.item(c).itemCode);
		     var businessPartner = new BusinessPartner
		    (results.rows.item(c).cardCode,
		    results.rows.item(c).cardName,
		    results.rows.item(c).licTradNum,
		    results.rows.item(c).email,
		    results.rows.item(c).phone1,
            results.rows.item(c).phone2,
            results.rows.item(c).balance,
            results.rows.item(c).contactCode,
            results.rows.item(c).contactName,
            results.rows.item(c).paymentGroupNum,
            results.rows.item(c).pymntGroup,
            results.rows.item(c).slpCode,
            results.rows.item(c).address,
            results.rows.item(c).mailAddress);
		     // alert(item.itemCode+ ' ' + item.itemName +'stock '+results.rows.item(c).stock);
			businessPartners.push(businessPartner);
	
        }
        
    $scope.businessPartners=businessPartners;
    $scope.$apply();
    
}

function errorInQuery(tx,error)
{
    
    alert(error.message); 
//alert(JSON.stringify(results));
      
} 




}

SelectBPController.$inject = ["$scope", "$http", "$filter"];

oneApp.controller('SelectBPController', SelectBPController);
