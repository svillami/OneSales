function Document (){

    //constructor(){
    this.docEntry;
    this.cardCode="";
    this.cardName="";
    this.docDate;
    this.taxDate; 
    this.baseImp=0;
    this.docTotal=0;
    this.docStatus;
    this.vatSum=0;
    this.discount=0;
    this.discountPercent=0;
    this.comments="";
    this.lines=new Array();
    this.currency="";
    this.paidToDate=0;
    this.pending=0;
    this.appliedSum=0;
    //}
}
