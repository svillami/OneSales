function DocumentLine (){

    //constructor(){
    this.itemCode="";
 	this.docEntry;
 	this.lineId;
    this.dscription="";
    this.quantity=0;
    this.taxCode=""; 
    this.price=0;
    this.lineTotal=0;
    this.vatSum=0;
    this.rate=0;
    this.currency="";
    this.discount=0;
    this.discountPercent=0;
    this.comments="";
    //}
}
