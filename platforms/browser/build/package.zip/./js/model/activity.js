function Activity (){

    //constructor(){
    this.id;
    this.cardCode="";
    this.cardName="";
    this.address;
    this.priority; 
    this.repeatOption; 
    this.action;
    this.duration;
    this.hour;
    this.businessPartner;
    //}
}
