function BankAccount (bankAcct,acctCode,acctName){

    //constructor(){
    this.id;
    this.bankAcct=bankAcct;
    this.acctCode=acctCode;
    this.acctName=acctName;
    
    //}
}
