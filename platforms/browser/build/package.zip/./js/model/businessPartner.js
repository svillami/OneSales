function BusinessPartner(cardCode,cardName,licTradNum,email,phone1,phone2,balance,contactCode,contactName,paymentGroupNum,pymntGroup,slpCode,address,mailAddress){

  //constructor(cardCode,cardName,licTradNum,email,phone1,phone2,balance,contactCode,contactName,paymentGroupNum,pymntGroup,slpCode,address,mailAddress){
	
	this.cardCode=cardCode;
    this.cardName=cardName;
    this.licTradNum=licTradNum;
    this.email=email;
    this.phone1=phone1;
    this.phone2=phone2;
    this.balance=balance;
    this.contactCode=contactCode;
    this.contactName=contactName;
    this.paymentGroupNum=paymentGroupNum;
    this.pymntGroup=pymntGroup;
    this.slpCode=slpCode;
    this.address=address;
    this.mailAddress=mailAddress;
    
  //}



}