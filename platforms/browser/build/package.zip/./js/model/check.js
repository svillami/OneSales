function Check(bankAccount,acctCode,nroCheck,checkDate,checkAmount){

  //constructor(itemCode,whsCode,whsName,onHand,isCommited){
	
	this.bankAccount=bankAccount;
	this.acctCode=acctCode;
    this.nroCheck=nroCheck;
    this.checkDate=checkDate;
    this.checkAmount=checkAmount;
  
  //}



}