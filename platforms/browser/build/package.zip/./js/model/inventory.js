function Inventory(itemCode,whsCode,whsName,onHand,isCommited){

  //constructor(itemCode,whsCode,whsName,onHand,isCommited){
	
	this.itemCode=itemCode;
    this.whsCode=whsCode;
    this.whsName=whsName;
    this.onHand=onHand;
    this.isCommited=isCommited;
   
  //}



}