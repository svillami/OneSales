class Price{

constructor(itemCode,priceList,price,currency,priceListName){
	
	this.itemCode=itemCode;
    this.priceList=priceList;
    this.price=price;
    this.currency=currency;
    this.priceListName=priceListName;
  }


}